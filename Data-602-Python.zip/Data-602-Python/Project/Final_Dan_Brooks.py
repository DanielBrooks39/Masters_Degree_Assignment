#Dan Brooks
#IS602 Final

import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re
plt.style.use('ggplot')

def read_URL(url):

    soup = BeautifulSoup(requests.get(url).text)

    return soup

def find_Table(soup, table_name):
    
    table = soup.find('table', attrs={'class': table_name})
    table_body = table.find('tbody')

    return table_body

def extract_Contents(table_body):

    data = []
    rows = table_body.find_all('tr')
    for row in rows:
        cols = row.find_all('td')
        cols = [ele.text.strip() for ele in cols]
        data.append([ele for ele in cols if ele])

    return data

def convert_Unicode(data, rows, cols):

    final = []
    for i in range(0,rows):
        for j in range(0,cols):
            final.append(data[i][j].encode('utf-8'))
    return final

#Pitching stats for teams
url = 'http://www.fangraphs.com/leaders.aspx?pos=all&stats=pit&lg=all&qual=0&type=8&season=2016&month=0&season1=2016&ind=0&team=0,ts&rost=0&age=0&filter=&players=0'
soup = read_URL(url)
table_body = find_Table(soup, 'rgMasterTable')
data = extract_Contents(table_body)
bat_pitch_type = convert_Unicode(data, 30, 19)

#Batting Stats for teams
url = 'http://www.fangraphs.com/leaders.aspx?pos=all&stats=bat&lg=all&qual=0&type=0&season=2016&month=0&season1=2016&ind=0&team=0,ts&rost=0&age=0&filter=&players=0&page=1_30'
soup = read_URL(url)
table_body = find_Table(soup, 'rgMasterTable')
data = extract_Contents(table_body)
bat_information = convert_Unicode(data, 30, 22)

bi_series = pd.Series(bat_information)
pi_series = pd.Series(bat_pitch_type)

#Batting stats for teams
columns = ['ID', 'Team', 'G', 'AB', 'PA', 'H', '1B', '2B', '3B', 'HR', 'R', 'RBI', 'BB', \
           'IBB', 'SO', 'HBP', 'SF', 'SH', 'GDP', 'SB', 'CS', 'AVG']
df_bi = pd.DataFrame(index = range(1,31),columns = columns)
df_bi = df_bi.fillna(" ")

k = 0

for i in range(0,30):
    for j in range(0,22):
        df_bi.iat[i,j] = pd.to_numeric(bi_series[k], errors = 'ignore')
        k = k + 1

#Pitching stats for teams
columns = ['ID', 'Team', 'W', 'L', 'SV', 'G', 'GS', 'IP', 'K/9', 'BB/9', 'HR/9', \
           'BABIP', 'LOB%', 'GB%', 'HR/FB', 'ERA', 'FIP', 'xFIP', 'WAR']
df_pi = pd.DataFrame(index = range(1,31),columns = columns)
df_pi = df_pi.fillna(" ")

k = 0

for i in range(0,30):
    for j in range(0,19):
        df_pi.iat[i,j] = pd.to_numeric(pi_series[k], errors = 'ignore')
        k = k + 1
        
#Sort dataframes
df_bi_sort = df_bi.sort_values(['Team'])
df_pi_sort = df_pi.sort_values(['Team'])

df_bi_sort['ID'] = range(1,31)
df_pi_sort['ID'] = range(1,31)

W_AVG = pd.DataFrame(index = range(1,31), columns = ['AVG', 'W'])
W_AVG['AVG'] = df_bi_sort['AVG']
W_AVG['W'] = df_pi_sort['W']/100
W_AVG.plot.line()
plt.show()
#Batting averages really have no effect on the numbe rof wins a team gets.
#Batting averages appear to be pretty even amongst all of the teams in 2016.
#THere are a lot of at bats throughout a baseball season, it would make sense
#that all of the averages are about even.

Hit_W = pd.DataFrame(index = range(1,31), columns = ['1B', '2B', '3B', 'HR'])
Hit_W['1B'] = df_bi_sort['1B']/10
Hit_W['2B'] = df_bi_sort['2B']/10
Hit_W['3B'] = df_bi_sort['3B']
Hit_W['HR'] = df_bi_sort['HR']/10
Hit_W['W'] = df_pi_sort['W']
Hit_W.plot.line()
plt.show()

#It appears from the graph above, that the number of wins a team has is based off of the
#amount of singles that a team has. The two lines look very similar. The other types of
#hits appear to really have no effect on wins. That could be duw to the fact that singles
#are the most common hit in baseball, so it would make sense that that effects wins.

ERA_SO_W = pd.DataFrame(index = range(1,31), columns = ['W', 'ERA', 'SO'])
ERA_SO_W['W'] = df_pi_sort['W']
ERA_SO_W['ERA'] = df_pi_sort['ERA']*10
ERA_SO_W['SO'] = df_bi_sort['SO']/20
ERA_SO_W.plot.line()
plt.show()
#As expected, as the number of wins decrease, the ERA increases. That makes since, because
#the era is roughly how may runs the pitcher will give up in a game/pitching outing.
#A lower ERA should result in more wins.The strike outs are a little surprising. I would
#have thought that there would have been a strong negative correaltion between wins and SO.
#I thought that teams with less wins would have more strike outs, but the stirke outs
#appear to be relatively even amongst all of the teams. That means that they really have
#not effect on wins.

