from bs4 import BeautifulSoup
from alchemyapi import AlchemyAPI
import json
import string
import urllib

def get_URL(url):
    try:
        sock = urllib.urlopen(url)
        htmlSource = sock.read()
        sock.close()
    except:
        print("Cannot open URL", url)

    return htmlSource

def extract_Data(html):
    soup = BeautifulSoup(html)
    paragraph = ''.join(text.strip() for text in soup.p.find_all(text = True, recursive = True))

    return paragraph

def API_data(data):
    alchemyapi = AlchemyAPI()
    
    print('Processing text: ', data)
    print('')

    repsonse = alchemyapi.keywords('text', data, {'sentiment': 1})

    keywordlist = []

    if response['status'] == 'OK':
        for keyword in response['keywords']:
            keywordlist.append([keyword['text'].encode('utf-8'), float(keyword['relevance'].encod('utf-8'))])
    else:
        print('Error in keyword extraction call: ', response['statusInfo'])
        
    keywordlist.sort(key=lambda x: x[1], reverse = True)

    print("Here are the top 10 keywords: \n")
    for i in range(0,10):
        print(keywordlist[i][0] + ", with a relevance score of: " + str(keywordlist[i][1]))

if __name__ == "__main__":
    
    url = "https://www.engadget.com/2014/02/10/you-can-now-play-most-embedded-youtube-videos-on-your-chromecast/"

    URL_info = get_URL(url)
    data = extract_Data(URL_info)
    API_data(data)



	
