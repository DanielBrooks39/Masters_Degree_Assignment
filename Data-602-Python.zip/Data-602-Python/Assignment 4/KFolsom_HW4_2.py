#!/usr/bin/env python

## --------------------------------
## Keith Folsom
## DATA 602 HW3
## --------------------------------

from alchemyapi import AlchemyAPI
from bs4 import BeautifulSoup
import json
import urllib
import pandas as pd
import sys

## --------------------------------
## Function: get_input_file
## --------------------------------
def get_url_text(URL):    

    """Extracts the text found in the paragraph tabs of the provided website

    Args: URL of the website to be parsed
    Returns: character string of the text found in the paragraph tags of the site

    Raises: 
    """

    try: 
        content = urllib.urlopen(URL).read()
        
    except:
        print("Cannot open URL", URL)
        
    # parse the website using beautifulsoup
    soup = BeautifulSoup(content, "lxml")

    # extract all of the paragraphs in the article
    para = soup.find_all("p")

    # remove the html tags and create a text string
    text = ""
    for element in para:
        #print(element.get_text().encode('utf-8'))   
        text += element.get_text().encode('utf-8')

    return(text)
    
## --------------------------------
## Function: get_input_file
## --------------------------------
def extract_keywords(text_input):    

    """Extracts the text found in the paragraph tabs of the provided website

    Args: URL of the website to be parsed
    Returns: character string of the text found in the paragraph tags of the site

    Raises: 
    """
    
    # Create the AlchemyAPI Object
    alchemyapi = AlchemyAPI()
    
    keyword_list = []
    relevance_list = []
    
    response = alchemyapi.keywords('text', text_input, {'sentiment': 1})
    
    if response['status'] == 'OK':
        #print('## Response Object ##')
        #print(json.dumps(response, indent=4))

        #append the keyword text and relevance to lists     
        for keyword in response['keywords']:
            keyword_list.append (keyword['text'].encode('utf-8'))
            relevance_list.append (keyword['relevance'])
                
    else:
        print('Error in keyword extaction call: ', response['statusInfo'])
        
    df = pd.DataFrame({'Keyword': keyword_list, 'Relevance': relevance_list})

    return(df)
    
## --------------------------------
## MAIN
## --------------------------------
if __name__ == "__main__":

    # we'll be processing an article this article on Jupiter
    URL = "http://www.npr.org/sections/thetwo-way/2016/09/26/495512651/nasa-spots-what-may-be-plumes-of-water-on-jupiters-moon-europa"
 
    # extract the paragraph text from the site
    text = get_url_text(URL)
    
    if text is None:
        print("No text retrieved from URL", URL)
        print("Processing stopped.")
        sys.exit(1)

    keywords_df = extract_keywords(text)
        
    print('')
    print('###########################################################')
    print('#   Keyword Extraction - Top 10 Keywords By Relevance     #')
    print('###########################################################')
    print('')
    
    print(keywords_df[0:10])

    print('')
    print('')
