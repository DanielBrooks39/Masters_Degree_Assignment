#1. fill in this class
#   it will need to provide for what happens below in the
#       main, so you will at least need a constructor that takes the values as (Brand, Price, Safety Rating),
#       a function called showEvaluation, and an attribute carCount
class CarEvaluation:
        carCount = 0
        'A simple class that represents a car evaluation'
        def __init__(self, Brand, Price, Safety_Rating):
                self.Brand = Brand
                self.Price = Price
                self.Safety_Rating = Safety_Rating
                self.__class__.carCount += 1
        def showEvaluation(self):
                print "The %s has a %s price and it's safety is rated a %s" \
                      % (self.Brand, self.Price, self.Safety_Rating)
        def priceToNumber(self):
                if(self.Price == "High"):
                        self.Price = 2
                elif(self.Price == "Med"):
                        self.Price = 1
                else:
                        self.Price = 0
                        
#2. fill in this function
#   it takes a list of CarEvaluation objects for input and either "asc" or "des"
#   if it gets "asc" return a list of car names order by ascending price
#       otherwise by descending price
def sortbyprice(L, Order):
        data = [(L[0].Brand, L[0].Price, L[0].Safety_Rating), \
                (L[1].Brand, L[1].Price, L[1].Safety_Rating), \
                (L[2].Brand, L[2].Price, L[2].Safety_Rating)]

        if(Order == "asc"):
                sort = sorted(data, key=lambda data: data[1])
        else:
                sort = sorted(data, key=lambda data: data[1], reverse = True)
                
        output = (sort[0][0], sort[1][0], sort[2][0])
                  
        return output         

#3. fill in this function
#   it takes a list for input of CarEvaluation objects and a value to search for
#       it returns true if the value is in the safety  attribute of an entry on the list,
#   otherwise false
def searchforsafety(L, Value):
      data = [(L[0].Brand, L[0].Price, L[0].Safety_Rating), \
              (L[1].Brand, L[1].Price, L[1].Safety_Rating), \
              (L[2].Brand, L[2].Price, L[2].Safety_Rating)]

#      for i in range(0, len(data) - 1):
#              if (Value == data[i][2]):
#                      return True
#              else:
#                      return False
      
      for i, (brand, price, rating) in enumerate( data):
              if (Value == rating):
                      return True
              else:
                      return False
        
# This is the main of the program.  Expected outputs are in comments after the function calls.
if __name__ == "__main__":      
   eval1 = CarEvaluation("Ford", "High", 2)
   eval2 = CarEvaluation("GMC", "Med", 4)
   eval3 = CarEvaluation("Toyota", "Low", 3)

   print "Car Count = %d" % CarEvaluation.carCount # Car Count = 3

   eval1.showEvaluation() #The Ford has a High price and it's safety is rated a 2
   eval2.showEvaluation() #The GMC has a Med price and it's safety is rated a 4
   eval3.showEvaluation() #The Toyota has a Low price and it's safety is rated a 3

   eval1.priceToNumber()
   eval2.priceToNumber()
   eval3.priceToNumber()
   
   L = [eval1, eval2, eval3]
   
   print sortbyprice(L, "asc"); #[Toyota, GMC, Ford]
   print sortbyprice(L, "des"); #[Ford, GMC, Toyota]
   print searchforsafety(L, 2); #true
   print searchforsafety(L, 1); #false
