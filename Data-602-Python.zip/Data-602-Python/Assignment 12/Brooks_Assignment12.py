import Tkinter
import tkFileDialog
import pandas as pd
import numpy as np
from pandas import Series
import os
import timeit
import ipyparallel

root = Tkinter.Tk()
root.withdraw()
file_p = tkFileDialog.askopenfilename(parent=root) # select the apple data file
AD = pd.read_csv(file_p)
AD.columns = ['date','price','p_change']

p = Series(AD['p_change'][1:],dtype=float) # not using first row (headers)
mu, sigma = np.mean(p), np.std(p)
mu, sigma

f_price = []
for i in range(0,10000):
    l_price = AD['price'][251] # the last row (we aren't looking at the headers)
    diff_20 = np.random.normal(mu, sigma, 20)
    next_20 = [] # nesting to keep it simple
    for e in diff_20:
        l_price = l_price + l_price * e #notation shared by David Stern
        next_20.append(l_price)
    f_price.append(next_20[19])

print np.percentile(f_price,1)

%timeit diff_20
f_price = []
for i in range(0,10000):
    l_price = AD['price'][251] # the last row (we aren't looking at the headers)
    diff_20 = np.random.normal(mu, sigma, 20)
    next_20 = [] # nesting to keep it simple
    for e in diff_20:
        l_price = l_price + l_price * e 
        next_20.append(l_price)
    f_price.append(next_20[19])

print np.percentile(f_price,1)

from ipyparallel import Client


c = Client()
clients = ipyparallel.Client()
dview = clients.direct_view()


%%px 
import Tkinter
import tkFileDialog
import pandas as pd
import numpy as np
from pandas import Series
import os
import timeit
import ipyparallel

root = Tkinter.Tk()
root.withdraw()
file_p = tkFileDialog.askopenfilename(parent=root) # select the apple data file
AD = pd.read_csv(file_p)
AD.columns = ['date','price','p_change']

# Analysis from HW11
p = Series(AD['p_change'][1:],dtype=float) # not using first row (headers)
mu, sigma = np.mean(p), np.std(p)
mu, sigma

# the parallel part
clients = ipyparallel.Client()
dview = clients.direct_view()

def rand20(mean,std):
    import random
    randomlist = []
    for i in range(0,20):
         randomlist.append(random.gauss(mean,std))
    return randomlist

c.ids
%%px 
f_price = []
diff_20 = []

%timeit diff_20
for i in range(0,10000):
    l_price = AD['price'][251] # the last row (we aren't looking at the headers)
    diff_20 = np.random.normal(mu, sigma, 20)
    next_20 = [] # nesting to keep it simple
    for e in diff_20:
        l_price = l_price + l_price * e 
        next_20.append(l_price)
    f_price.append(next_20[19])

print np.percentile(f_price,1) 






