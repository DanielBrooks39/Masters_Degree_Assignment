#Dan Brooks
#DATA602 Advanced Programming
#Assignment 6

import numpy
import timeit

#1. fill in this function
#   it takes a list for input and return a sorted version
#   do this with a loop, don't use the built in list functions
def sortwithloops():
    random_num = random.sample(xrange(101), 101)
    count = 0
    
    for i in range(0, len(random_num) - 1 ):
         for k in range(i, len(random_num), 1 ):
             count +=1
             if (random_num[k]< random_num[k - 1] ):
                  tmp = random_num[k]
                  random_num[k] = random_num[k-1]
                  random_num[k-1] = tmp
    return count
	
#2. fill in this function
#   it takes a list for input and return a sorted version
#   do this with the built in list functions, don't us a loop
def sortwithoutloops():
    #Big O nlog(n)
    random_num = random.sample(xrange(101), 101)
    random_num.sort()
    return random_num

def sortnumpy():
#Big O of n squared
    random_num = random.sample(xrange(101), 101)
    numpy.sort(random_num, kind = 'quicksort')
    return random_num

if __name__ == "__main__":
    #Create a random list of 1000000 integers	
    import random
    
    t = timeit.Timer("sortwithloops()", "from __main__ import sortwithloops",)
    print "The time for sorting with loops is: ", t.timeit(sortwithloops())
    
    t = timeit.Timer("sortwithoutloops()", "from __main__ import sortwithoutloops")
    print "The time for sorting without loops is: ", t.timeit(sortwithoutloops())
    
    t = timeit.Timer("sortnumpy()")
    print "The time for sorting with numpy is: ", t.timeit(sortnumpy())

    
    


