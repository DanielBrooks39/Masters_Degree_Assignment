import Tkinter
import tkFileDialog
import mahotas as mh
import pylab

print "First select the circles.png file using the dialog box"

root = Tkinter.Tk()
root.withdraw()
filename = tkFileDialog.askopenfilename(parent=root)

def circles():
    my_image = mh.imread(filename)
    thres = mh.rc(my_image)
    b_image = (my_image > thres)
    g_image = mh.gaussian_filter(b_image, 33)
    rmax = mh.regmax(g_image)
    labeled, nr_objects = mh.label(rmax)
    centers = mh.center_of_mass(my_image, labeled)[1:]
    print "The circles.png file contains ", nr_objects, " objects."
    o = 1
    for center in centers:
        print "Object %s center: [ %s, %s ]" %(o, round(center[1], 4), round(center[0],4))
        o = o + 1

circles()

print "Next run the same tests on the objects.png file by selecting it using the dialog box"

root = Tkinter.Tk()
root.withdraw()
filename2 = tkFileDialog.askopenfilename(parent=root)

def objects():
    my_image = mh.imread(filename2)
    b_image = (my_image > my_image.mean())
    g_image = mh.gaussian_filter(b_image, 1.5)
    labeled, nr_objects = mh.label(g_image)
    centers = mh.center_of_mass(my_image, labeled)[1:]
    print "The objects.png contains ", nr_objects, " objects."
    o = 1
    for center in centers:
        print "Object %s center: [ %s, %s ]"  %(o, round(center[1], 4), round(center[0], 4))
        o = o + 1

objects()

print "Last we test the peppers.png file by selecting it using the dialog box"

root = Tkinter.Tk()
root.withdraw()
filename3 = tkFileDialog.askopenfilename(parent=root)

def peppers():
    my_image = mh.imread(filename3)
    T = mh.otsu(my_image)
    b_image = (my_image > T)
    g_image = mh.gaussian_filter(b_image, 15)
    rmax = mh.regmax(g_image)
    labeled, nr_objects = mh.label(rmax)
    centers = mh.center_of_mass(my_image, labeled)[1:]
    print "The peppers.png file contains ", nr_objects, " objects."
    o = 1
    for center in centers:
        print "Object %s center: [ %s, %s ]" %(o, round(center[1], 4), round(center[0], 4))
        o = o + 1


peppers()
