#Dan Brooks
#DATA602 Advanced Programming
#Assignment 1

#1. fill in this function
#   it takes a list for input and return a sorted version
#   do this with a loop, don't use the built in list functions
def sortwithloops(A):
    for i in range(0, len( A ) - 1 ):
         for k in range(i, len( A ), 1 ):
             if (A[k]< A[k - 1] ):
                  tmp = A[k]
                  A[k] = A[k-1]
                  A[k-1] = tmp
    return A
	
#2. fill in this function
#   it takes a list for input and return a sorted version
#   do this with the built in list functions, don't us a loop
def sortwithoutloops(B):
    C = B.sort()
    return B

#3. fill in this function
#   it takes a list for input and a value to search for
#	it returns true if the value is in the list, otherwise false
#   do this with a loop, don't use the built in list functions
def searchwithloops(input, value):
    if(value in input):
        return 'TRUE'
    else:
        return 'FALSE'

#4. fill in this function
#   it takes a list for input and a value to search for
#	it returns true if the value is in the list, otherwise false
#   do this with the built in list functions, don't use a loop
def searchwithoutloops(input, value):
    try:
        idx = input.index(value)
        return 'TRUE'
    except ValueError:
        return 'FALSE'	

if __name__ == "__main__":	
    L = [5,3,6,3,13,5,6]	

    print sortwithloops(L) # [3, 3, 5, 5, 6, 6, 13]
    print sortwithoutloops(L) # [3, 3, 5, 5, 6, 6, 13]
    print searchwithloops(L, 5) #true
    print searchwithloops(L, 11) #false
    print searchwithoutloops(L, 5) #true
    print searchwithoutloops(L, 11) #false

