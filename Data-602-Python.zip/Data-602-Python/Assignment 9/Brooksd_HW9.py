# Dan Brooks
# Homework Assignment 9

import re
import pandas as pd
import numpy as np
from StringIO import StringIO
import Tkinter
import tkFileDialog


def data_clean(data_file):

    pattern = r"(\" )(?=HTTP)"  

    with open(data_file) as d:
        raw = d.read()

    f_txt = re.sub(pattern, " ", raw) 

    x = StringIO(f_txt) 

    df = pd.read_csv(x, sep="\s+", header=None, na_values="-")
    df.columns = ['IP_address', 'time_stamp', 'request', 'status', 'bytes']

    df['time_stamp'] += "1995-08" 
    df['time_stamp'] = pd.to_datetime(df['time_stamp'], format="[%d:%H:%M:%S]%Y-%m")

    return df

root = Tkinter.Tk()
root.withdraw()
file_p = tkFileDialog.askopenfilename(parent=root)

new_data = data_clean(file_p)

print new_data[:5]

# 1. Which hostname or IP address made the most requests?
print "IP_address or hostname with most requests:"
print new_data['IP_address'].value_counts()[:1]

# 2. Which hostname or IP address received the most total bytes from the server? How many bytes did it receive?
ip_1 = new_data.groupby(new_data.IP_address)
byte_totals = ip_1['bytes'].aggregate(np.sum)
byte_totals.sort(inplace=True, ascending=False)
print "IP_address and hostname with most total bytes:"
print byte_totals[:1]

#3. During what hour was the server the busiest in terms of requests?
time_1 = new_data.groupby(new_data['time_stamp'].dt.hour)
group_size = time_1.size()
group_size.sort(inplace=True, ascending=False)
print "Busiest server hour | number of requests:"
print "                 " + str(group_size[:1]) 

#4 Which .gif image was downloaded the most during the day?
s = new_data[(new_data.status == 200) & (new_data.request.str.contains('\\.gif'))]
print "                Most downloaded gif image | download count"
print s.request.value_counts()[:1]

#5 What HTTP reply codes were sent other than 200?
http_s = new_data[new_data.status != 200]
print "Codes | counts:"
print http_s.status.value_counts()
