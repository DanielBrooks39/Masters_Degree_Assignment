def getpath():
    "Get the file path for the file on the users computer"
    from sys import version_info
    py3 = version_info[0] > 2

    if py3:
        response = input("Please Enter Entire File Path: ")
    else:
        response = raw_input("Please Enter Entire File Path: ")
    return(response)

def readfile(files):
    "Read in the file line by line and parses out the record \
     split[0] = Buying \
     split[1] = Maint \
     split[2] = doors \
     split[3] = persons \
     split[4] = lug_boot \
     split[5] = Safety"
    
    output = list()
    buying = ("vhigh", "high", "med", "low")
    maint = ("vhigh", "high", "med", "low")
    doors = ("2", "3", "4", "5more")
    persons = ("2", "4", "more")
    lug_boot = ("small", "med", "big")
    safety = {"low", "med", "high"}

    count = 1
    
    for line in files:
        split = line.split(',')

        if (split[0] in buying) and \
           (split[1] in maint) and \
           (split[2] in doors) and \
           (split[3] in persons) and \
           (split[4] in lug_boot) and \
           (split[5] in safety):
            FileData = [split[0],
                        split[1],
                        split[2],
                        split[3],
                        split[4],
                        split[5]]
            output.append(FileData)
            count += 1
            
        else:
           output = "Invalid Input"
           break

    return (output, count)

def closefile(files):
    "Closes the file after it has been read"
    files.close()
    closed = files.closed
    return closed
    
def openfile(path):
    "Opens the file for processing"
    openedfile = open(path)
    return openedfile
    
def sortBySafety(data1, Order = "desc"):
    "Sorts the list by the safety category"
    
    data = data1
    for i in range(0, len(data) - 1):
        if(data[i][5] == "low"):
            data[i][5] = 0
        elif(data[i][5] == "med"):
            data[i][5] = 1
        else:
            data[i][5] = 2
            
    if (Order == "asc"):
        sort = sorted(data, key = operator.itemgetter(5))
    else:
        sort = sorted(data, key = operator.itemgetter(5), reverse = True)

    for i in range(0, len(sort) - 1):
        if(sort[i][5] == 0):
            sort[i][5] = "low"
            data[i][5] = "low"
        elif(sort[i][5] == 1):
            sort[i][5] = "med"
            data[i][5] = "med"
        else:
            sort[i][5] = "high"
            data[i][5] = "high"
            
    output = sort[:10]
    return output

def sortByMaint(data1, Order = "asc"):
    "Sorts the list by the maint category"
    
    data = data1
    for i in range(0, len(data) - 1):
        if(data[i][1] == "low"):
            data[i][1] = 0
        elif(data[i][1] == "med"):
            data[i][1] = 1
        elif(data[i][1] == "high"):
            data[i][1] = 2
        else:
            data[i][1] = 3
            
    if (Order == "asc"):
        sort = sorted(data, key = operator.itemgetter(1))
    else:
        sort = sorted(data, key = operator.itemgetter(1), reverse = True)
        
    for i in range(0, len(sort) - 1):
        if(sort[i][1] == 0):
            sort[i][1] = "low"
            data[i][1] = "low"
        elif(sort[i][1] == 1):
            sort[i][1] = "med"
            data[i][1] = "med"
        elif(sort[i][1] == 2):
            sort[i][1] = "high"
            data[i][1] = "high"
        else:
            sort[i][1] = "vhigh"
            data[i][1] = "vhigh"
    output = sort[-15:]
    return output

def filterList(data1, Order = "asc"):
    "Filter buying, maint and saftey fields into only vhigh and high values"

    data = data1
    pattern = "v*high"
    new_test = list()
    
    for i in range(0, len(data) - 1):
        if(bool(re.search(pattern, data[i][0])) == True) or \
          (bool(re.search(pattern, data[i][1])) == True) or \
          (bool(re.search(pattern, data[i][5])) == True):

            new_test.append(data[i])
            
    if (Order == "asc"):
        sort = sorted(new_test, key = operator.itemgetter(2))
    else:
        sort = sorted(new_test, key = operator.itemgetter(2), reverse = True)         
        
    return sort

def filterOuput(data1):
    "filter data to \
    buying: vhigh \
    maint: med \
    doors: 4 \
    persons: 4 or more"
    
    data = data1
    new_test = list()
    
    for i in range(0, len(data) - 1):
        if(data[i][0] == "vhigh") and \
          (data[i][1] == "med") and \
          (data[i][2] == '4') and \
          (data[i][3] != '2'):

            new_test.append(data[i])

    return new_test

def writefile(data):
    "Writes the file line by line to output.txt"
    
    f = open('output.txt', 'a')
    
    for i in range(0, len(data) - 1):
        for j in range(0,5,1):
            f.write(data[i][j] + ',')
        f.write('\n')
    f.close

def printSafety(data):
    "Prints the Safety data to the screen"
    
    for i in range(0,10,1):
        print data[i][0] + ',' + data[i][1] + ',' + data[i][2] + ',' + data[i][3] + ',' \
              + data[i][4] + ',' + data[i][5] 
    print "\n"

def printMaint(data):
    "Prints the Maint field to the screen"
                           
    for i in range(0,15,1):
        print data[i][0] + ',' + data[i][1] + ',' + data[i][2] + ',' + data[i][3] + ',' \
              + data[i][4] + ',' + data[i][5] 
    print "\n"

def printData(data):
    "Prints all of the data that has been filtered"
    
    for i in range(0,len(data) - 1, 1):
        print data[i][0] + ',' + data[i][1] + ',' + data[i][2] + ',' + data[i][3] + ',' \
              + data[i][4] + ',' + data[i][5]
    
if __name__ == "__main__":
    import re
    import operator
    
    path = getpath()

    for i in range(500):
        try:
            openthefile = openfile(path)
            filedata = readfile(openthefile)
            closefile(openthefile)
            break
        except IOError:
            print "Invalid File Name. Please Try Again."
            path = getpath()
            
    if (filedata[0] == "Invalid Input"):
        print "Invalid Input"
        print "Invalid Record in Row %d" % (filedata[1])
        print "Please Change the Record"
    else:
        sortsafety = sortBySafety(filedata[0])
        printSafety(sortsafety)
        sortmaint = sortByMaint(filedata[0])
        printMaint(sortmaint)
        filterdata = filterList(filedata[0])
        printData(filterdata)
        output = filterOuput(filedata[0])
        writefile(filedata[0])
    
            
        

    
