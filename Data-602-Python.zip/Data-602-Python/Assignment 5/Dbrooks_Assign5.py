import csv
import math

def read_CSV(csv_file):
    
    '''This function will read the data from the brainandbody csv file
       It takes in the csv file and returns a list
       The first item in the list is the brain data
       The second item is the body data
    '''
    
    brain_weights = []
    body_weights = []
    
    with open(csv_file) as csvfile:
        readCSV = csv.reader(csvfile, delimiter = ',')

        for row in readCSV:
            brain_weight = row[2]
            body_weight = row[1]

            brain_weights.append(brain_weight)
            body_weights.append(body_weight)

    brain_data = [float(i) for i in brain_weights[1:]]
    body_data = [float(i) for i in body_weights[1:]]
    
    return (brain_data, body_data)

def average_Values(csvdata):
    '''Gets the averages of the x and y variables
    '''

    sum_brain = sum(csvdata[0])
    sum_body = sum(csvdata[1])

    average_brain = sum_brain/len(csvdata[0])
    average_body = sum_body/len(csvdata[1])

    return (average_brain, average_body)

def calc_Slope(data, averages):
    '''brain[0], body[1], x = brain, y = body'''
    
    numerator = 0
    denominator = 0
    for i in range(0, len(data[1])):
        numerator += (data[1][i] - averages[1]) * (data[0][i] - averages[0])
        denominator += (data[0][i] - averages[0])**2

    slope = numerator/denominator

    return slope

def calc_Intercept(averages, slope):
    '''gets the intercept of the regression line'''

    intercept = averages[1] - slope*averages[0]

    return intercept

def r_Value(data):
    '''Calculate the R value for the equation
       brain[0], body[1], x = brain, y = body'''

    xy = [data[0][i] * data[1][i] for i in range(len(data[1]))]
    xsquare = [data[0][i] * data[0][i] for i in range(len(data[0]))]
    ysquare = [data[1][i] * data[1][i] for i in range(len(data[1]))]
    
    sum_xy = len(data[1])*sum(xy)
    sumx_sumy = sum(data[0]) * sum(data[1])

    numerator = sum_xy - sumx_sumy

    sum_xsquare = len(data[0])*sum(xsquare)
    sumx_square = sum(data[0])**2
    sum_ysquare = len(data[1])*sum(ysquare)
    sumy_square = sum(data[1])**2

    denominator = math.sqrt((sum_xsquare - sumx_square)*(sum_ysquare - sumy_square))

    r_value = numerator/denominator

    return r_value

if __name__ == "__main__":

    data = read_CSV("brainandbody.csv")
    averages = average_Values(data)
    slope = round(calc_Slope(data, averages),5)
    intercept = round(calc_Intercept(averages, slope),5)
    r = round(r_Value(data),5)
    r_square = round(r**2,5)

    print "The equation of the line is: Body Weight = %s * Brain Weight + %s" % (slope, intercept)
    print "The R  Value is %s" % r
    print "The R Squared value is %s" % r_square

