# IS606
Statistics and Probability for Data Analytics DATA
