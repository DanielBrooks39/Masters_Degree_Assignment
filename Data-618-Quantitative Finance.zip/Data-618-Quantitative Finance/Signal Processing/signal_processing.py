import numpy as np
import pytz

import math
import datetime as dt
import statsmodels.tsa.stattools as ts
import statsmodels.api as sm
import pandas as pd
import cufflinks as cf

import Quandl as quandl

import plotly.plotly as py
import plotly.graph_objs as go
%matplotlib inline

pair =  ('GOOG', 'AAPL')

stock1 = 'WIKI/' + pair[0]
stock2 = 'WIKI/' + pair[1]

stocks = pd.concat([quandl.get(stock1, authtoken="1Cx13bkj4vDb7E13GLD6")['Adj. Close'].ix['01/01/2011':'04/30/2016'],
                    quandl.get(stock2, authtoken="1Cx13bkj4vDb7E13GLD6")['Adj. Close'].ix['01/01/2011':'04/30/2016']], 
                   axis=1).dropna()

stocks.columns = [pair[0], pair[1]]

#stocks = stocks.apply(np.log10, axis=1)

pair =  ('EWA', 'EWC')

#stock1 = 'GOOG/AMEX_' + pair[0]
#stock2 = 'GOOG/AMEX_' + pair[1]

stocks = pd.concat([quandl.get(stock1, authtoken="1Cx13bkj4vDb7E13GLD6")['Close'].ix['01/01/2011':'04/30/2016'],
                    quandl.get(stock2, authtoken="1Cx13bkj4vDb7E13GLD6")['Close'].ix['01/01/2011':'04/30/2016']], 
                   axis=1).dropna()

stocks.columns = [pair[0], pair[1]]

#stocks = stocks.apply(np.log10, axis=1)

x = pd.read_csv('x.csv', header=None)

y = pd.read_csv('y.csv', header=None)

x = np.array(x)
y = np.array(y)

x = np.concatenate([stocks[pair[0]].values.reshape(-1,1), np.ones([len(stocks[pair[0]].values),1])], axis=1)
y = stocks[pair[1]].values.reshape(-1,1)

delta = 0.0001

yhat = [] # Measurement Prediction

e = [] # Measurement prediction error

Q = [] # Measurement prediction error variance

# R(t|t) will be P(t)

P = np.zeros([2,2])

R = np.zeros([2,2])

beta = np.zeros([2,1])

Vw = (delta / (1-delta)) * np.eye(2)

Ve = 0.001

for i in np.arange(0, np.size(y)):
#for i in np.arange(0, 10):
    if i > 0:
        beta = np.concatenate([beta, beta[:,-1].reshape(-1,1)], axis=1) # State prediction
        R = P + Vw # State Covariance Prediction, 3.8

    yhat.append(x[i, :].dot(beta[:,i])) # Measurement Prediction, Equation 3.9

    Q.append(float(x[i,:].dot(R.dot(x[i,:].reshape(-1,1))) + Ve)) # Measurement variance prediction, Equation 3.10

    #Observe y(t)
    e.append(float(y[i] - yhat[i]))

    K = R.dot(x[i,:].reshape(-1,1))/Q[i] # Kalman Gain

    beta[:,i] = beta[:,i] + K[:,0]*e[-1] # State update
    
    P = R - (K*x[i,:]).dot(R)
    
    #P=R-K*x(t, :)*R;
stocks['yhat'] = yhat
stocks['beta0'] = beta[0,:]
stocks['beta1'] = beta[1,:]

trace = go.Scatter(
    x = stocks.index[2:],
    y = stocks['beta0'].values[2:]
)

layout = dict(title = 'Kalman Estimate of the Slope',
              xaxis = dict(title = 'Date'),
              yaxis = dict(title = 'Slope'),
)

fig = dict(data = [trace], layout = layout)

py.iplot(fig, filename = 'Kalman Slope')

trace = go.Scatter(
    x = stocks.index[2:],
    y = stocks['beta1'].values[2:]
)

layout = dict(title = 'Kalman Estimate of the Intercept',
              xaxis = dict(title = 'Date'),
              yaxis = dict(title = 'Intercept'),
)

fig = dict(data = [trace], layout = layout)

py.iplot(fig, filename = 'Kalman Intercept')

a = np.array([1,2]).reshape(1,-1)
np.concatenate([a, np.array([[1,2]])], axis=0)

a = np.array([2]).reshape(1,-1)
np.concatenate([a, [2]], axis=0)

beta
